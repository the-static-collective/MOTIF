from .server import stdio_server
stdio_server()
