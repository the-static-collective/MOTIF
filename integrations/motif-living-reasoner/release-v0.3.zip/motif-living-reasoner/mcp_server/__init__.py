"""Personal MOTIF MCP server — bounded routing with durable, reviewed sessions."""
