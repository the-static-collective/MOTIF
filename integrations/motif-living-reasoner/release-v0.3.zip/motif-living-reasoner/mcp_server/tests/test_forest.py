"""Forest v0.3 verification: source-only discovery, RING003 selection, review gates."""
import base64
from hashlib import sha1
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from mcp_server import forest
from mcp_server.service import MotifService
from mcp_server.server import dispatch, rpc


class MockGitHub:
    def __init__(self):
        self.n=0

    def __call__(self,url):
        if '/branches?' in url:
            self.n+=1
            return [{'name':'experiment/new-branch','commit':{'sha':'f'*40}},
                    {'name':'main','commit':{'sha':'e'*40}}]
        if '/contents/' in url:
            b=b'# pinned UTF-8 source text\n'
            return {'type':'file','encoding':'base64',
                    'content':base64.b64encode(b).decode(),
                    'sha':sha1((f'blob {len(b)}\0').encode()+b).hexdigest()}
        raise AssertionError(url)


class FakeNative:
    def __init__(self):self.runs=[]
    def run(self,kind,selection,seed,count):
        self.runs.append((kind,list(selection),seed,count))
        doc={'schema':'motif.shared-evidence-benchmark.v1',
             'status':'SOURCE_NATIVE_COMMON_WORLD_SYNTHETIC_EVALUATION',
             'kind':kind,'count':count,'seed':seed,'external_action_executed':False,
             'real_world_authority':False,
             'strong_classical_baseline_matches_or_exceeds':True}
        doc['receipt_sha256']=forest.digest(doc)
        return doc


FULL_GOAL={'cross-instrument-evidence-review':18}

class ForestTests(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.runner=FakeNative()
        self.fetch=MockGitHub()
        self.store=forest.ForestService(Path(self.tmp.name)/'forest.db',runner=self.runner,fetch=self.fetch)

    def test_selected_three_joint_methods_and_controls(self):
        result=forest.route(FULL_GOAL,6,3)
        self.assertEqual(set(result['selected']['selected']),set(forest.METHODS))
        self.assertEqual(result['selected']['missing'],[])
        self.assertEqual(result['selected']['declared_tension_penalty'],3)
        self.assertFalse(result['joint_task_success_measured'])
        self.assertTrue(result['design_hypotheses_not_empirical_capabilities'])
        # Single-method options don't have the required many-tail affordance.
        self.assertEqual(forest.route({'utterance-classification':10},6,3)['selected']['selected'],['thought.language-dev'])
        self.assertRaises(forest.ForestError,forest.route,{'arbitrary-unauthorized-run':100},6,3)

    def test_complete_live_catalog_and_pinned_read_only_source(self):
        c=self.store.catalog(refresh=True,limit=1)
        self.assertEqual(c['total'],2)
        self.assertEqual(c['passports'][0]['state'],'INDEXED_NON_EXECUTABLE')
        self.assertFalse(c['passports'][0]['executable'])
        self.assertEqual(self.fetch.n,1)
        nextc=self.store.catalog(offset=1,limit=1)
        self.assertEqual(nextc['snapshot_id'],c['snapshot_id'])
        src=self.store.source(c['snapshot_id'],'experiment/new-branch','experiments/example/README.md')
        self.assertEqual(src['source_commit'],'f'*40)
        self.assertTrue(src['text'].startswith('# pinned'))
        self.assertRaises(forest.ForestError,self.store.source,c['snapshot_id'],'experiment/new-branch','../../etc/passwd')
        self.assertRaises(forest.ForestError,self.store.source,c['snapshot_id'],'other-branch','experiments/hello.md')

    def test_refresh_failure_does_not_replace_complete_snapshot(self):
        c=self.store.catalog(refresh=True)
        def bad(_):raise forest.ForestError('blocked')
        self.store.fetch=bad
        self.assertRaises(forest.ForestError,self.store.catalog,True)
        after=self.store.catalog(refresh=False)
        self.assertEqual(after['snapshot_id'],c['snapshot_id'])

    def test_approval_execution_reinspection_return(self):
        s=self.store.start(FULL_GOAL,count=4)
        self.assertEqual(s['stage'],'PLAN_REVIEW')
        self.assertRaises(forest.ForestError,self.store.execute,s['session_id'],1)
        self.assertEqual(self.runner.runs,[])
        a=self.store.feedback(s['session_id'],1,'approve','Operator approved synthetic trial')
        self.assertEqual(a['stage'],'READY')
        self.assertRaises(forest.ForestError,self.store.execute,s['session_id'],1)
        r=self.store.execute(s['session_id'],2)
        self.assertEqual(r['stage'],'RESULT_REVIEW')
        self.assertEqual(len(self.runner.runs),1)
        self.assertIn('independently authored',r['reflection']['next_question'])
        out=self.store.feedback(s['session_id'],3,'accept','Preserve classical tie and failure evidence')
        self.assertEqual(out['stage'],'RETURNED')
        self.assertEqual(self.store.resume(s['session_id'])['revision'],4)
        self.assertRaises(forest.ForestError,self.store.feedback,s['session_id'],4,'approve','No')

    def test_incompatible_trial_rejected_not_falsely_composed(self):
        with self.assertRaises(forest.ForestError):
            self.store.start({'proof-review':10},kind='shared_world_004')
        s=self.store.start({'proof-review':10},kind='native_triad_002')
        self.assertEqual(s['plan']['selected']['selected'],['reason.proof-objection'])

    def test_forged_event_and_result_hash_rejected(self):
        s=self.store.start(FULL_GOAL)
        with self.store._conn() as db:
            revision, raw=db.execute('SELECT revision,body FROM forest_trials WHERE id=?',(s['session_id'],)).fetchone()
            row=json.loads(raw)
            row['events'][0]['kind']='FAKE_APPROVAL'
            db.execute('UPDATE forest_trials SET body=? WHERE id=?',(json.dumps(row),s['session_id']))
        self.assertRaises(forest.ForestError,self.store.resume,s['session_id'])

    def test_native_runner_no_docker_no_execute(self):
        runner=forest.NativeRunner(repo_root='/tmp/nonexistent-git-repository')
        with self.assertRaises(forest.ForestError):
            runner.run('shared_world_004',list(forest.METHODS),7,4)

    def test_mcp_tools_dispatch_including_review(self):
        service=MotifService(Path(self.tmp.name)/'shared.db')
        service.forest=forest.ForestService(service.db_path,runner=self.runner,fetch=self.fetch)
        info=dispatch(service,'forest_goals',{})
        self.assertIn('cross-instrument-evidence-review',info['goals'])
        c=dispatch(service,'forest_catalog',{'refresh':True,'limit':2})
        self.assertEqual(c['total'],2)
        req={'goals':FULL_GOAL,'count':3}
        s=dispatch(service,'forest_start_trial',req)
        good=dispatch(service,'forest_feedback',{'forest_session_id':s['session_id'],
            'expected_revision':1,'decision':'approve','review_note':'Yes test the pinned synthetic triple'})
        done=dispatch(service,'forest_execute_reviewed',{'forest_session_id':s['session_id'],'expected_revision':2})
        self.assertEqual(done['result']['count'],3)
        self.assertEqual(good['stage'],'READY')
        reply=rpc(service,{'jsonrpc':'2.0','id':5,'method':'tools/list'})
        self.assertGreaterEqual(len(reply['result']['tools']),18)

if __name__=='__main__':unittest.main()
