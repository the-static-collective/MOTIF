import json
import os
from pathlib import Path
import tempfile
import unittest

from fastapi.testclient import TestClient
from mcp_server.service import MotifService, ServiceError
from mcp_server.server import create_app, rpc, TOOLS

TEST_KEY='motif_test_secret_please_do_not_use_in_production_0123456789'
CASE_PATH=Path(__file__).resolve().parents[2] / 'examples' / 'first-spiral.json'

class ServerTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory()
        self.service=MotifService(Path(self.td.name)/'state.sqlite3')
        self.case=json.loads(CASE_PATH.read_text())
        self.client=TestClient(create_app(service=self.service,api_key=TEST_KEY))
        self.headers={'Authorization':'Bearer '+TEST_KEY,
                      'Accept':'application/json, text/event-stream',
                      'Content-Type':'application/json'}

    def tearDown(self):
        self.client.close()
        self.td.cleanup()

    def call(self, name, args, *, id=3):
        r=self.client.post('/mcp',headers=self.headers,json={
            'jsonrpc':'2.0','id':id,'method':'tools/call',
            'params':{'name':name,'arguments':args}})
        self.assertEqual(r.status_code,200)
        return r.json()['result']

    def test_protocol_init_and_tool_discovery(self):
        r=self.client.post('/mcp',headers=self.headers,json={
            'jsonrpc':'2.0','id':1,'method':'initialize',
            'params':{'protocolVersion':'2025-06-18','capabilities':{},
                      'clientInfo':{'name':'test','version':'1'}}})
        self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()['result']['protocolVersion'],'2025-06-18')
        r=self.client.post('/mcp',headers=self.headers,json={'jsonrpc':'2.0','method':'notifications/initialized'})
        self.assertEqual(r.status_code,202)
        r=self.client.post('/mcp',headers=self.headers,json={'jsonrpc':'2.0','id':2,'method':'tools/list'})
        self.assertEqual(r.status_code,200)
        self.assertEqual(len(r.json()['result']['tools']),18)
        self.assertEqual(r.json()['result']['tools'][0]['annotations']['readOnlyHint'],True)
        self.assertEqual(self.client.get('/mcp',headers=self.headers).status_code,405)
        self.assertEqual(self.client.get('/healthz').status_code,200)

    def test_auth_and_origins_and_accept(self):
        self.assertEqual(self.client.post('/mcp',headers={'Accept':'application/json,text/event-stream'},json={}).status_code,401)
        h={**self.headers,'Origin':'https://evil.example'}
        self.assertEqual(self.client.post('/mcp',headers=h,json={}).status_code,403)
        h={**self.headers,'Accept':'application/json'}
        self.assertEqual(self.client.post('/mcp',headers=h,json={}).status_code,406)

    def test_shared_case_approval_execution_feedback_return(self):
        cat=self.call('catalog_cartridges',{})
        self.assertFalse(cat['isError'])
        self.assertEqual(cat['structuredContent']['method_count'],6)
        route=self.call('select_methods',{'case':self.case})
        self.assertFalse(route['isError'])
        self.assertFalse(route['structuredContent']['persisted'])
        start=self.call('start_session',{'case':self.case})
        self.assertFalse(start['isError'])
        a=start['structuredContent']; sid=a['session_id']
        self.assertEqual((a['stage'],a['revision']),('PLAN_REVIEW',1))
        self.assertFalse(a['inspection']['routing']['missing'])
        self.assertEqual(self.call('list_sessions',{'limit':5})['structuredContent']['sessions'][0]['session_id'], sid)
        out=self.call('execute_reviewed',{'session_id':sid,'expected_revision':1})
        self.assertTrue(out['isError'])
        ok=self.call('record_feedback',{'session_id':sid,'expected_revision':1,
             'decision':'approve','review_note':'User explicitly approved this plan.'})
        self.assertFalse(ok['isError'])
        self.assertEqual(ok['structuredContent']['stage'],'READY')
        done=self.call('execute_reviewed',{'session_id':sid,'expected_revision':2})
        self.assertFalse(done['isError'])
        d=done['structuredContent']
        self.assertEqual(d['stage'],'RESULT_REVIEW')
        self.assertTrue(d['result']['shared_case_processed'])
        self.assertIn('reflection',d)
        self.assertIn('next_human_question',d['reflection'])
        held=self.call('record_feedback',{'session_id':sid,'expected_revision':2,
             'decision':'accept','review_note':'Stale concurrency update'})
        self.assertTrue(held['isError'])
        res=self.call('resume_session',{'session_id':sid})['structuredContent']
        self.assertEqual(res['revision'],3)
        accepted=self.call('record_feedback',{'session_id':sid,'expected_revision':3,
             'decision':'accept','review_note':'User reviewed result and accepts research artifact.',
             'observed_outcome':'Not yet verified externally'})
        self.assertEqual(accepted['structuredContent']['stage'],'RETURNED')
        new=self.call('reopen_session',{'session_id':sid,'expected_revision':4,
                     'review_note':'New evidence available','updated_case':self.case})
        self.assertEqual(new['structuredContent']['cycle'],2)
        self.assertEqual(new['structuredContent']['stage'],'PLAN_REVIEW')
        self.assertEqual(new['structuredContent']['revision'],5)

    def test_revise_requires_updated_case(self):
        s=self.service.start(self.case)
        with self.assertRaises(ServiceError):
            self.service.feedback(s['session_id'],1,'revise','New human correction')
        self.assertEqual(self.service.resume(s['session_id'])['revision'],1)
        revised=json.loads(json.dumps(self.case))
        revised['question']='Reframed source-grounded question?'
        s2=self.service.feedback(s['session_id'],1,'revise','Human reframed question',updated_case=revised)
        self.assertEqual(s2['cycle'],2)
        self.assertEqual(s2['stage'],'PLAN_REVIEW')

    def test_hold_and_reopen(self):
        s=self.service.start(self.case)
        h=self.service.feedback(s['session_id'],1,'hold','Human wishes to stop')
        self.assertEqual(h['stage'],'HELD')
        with self.assertRaises(ServiceError):self.service.execute(s['session_id'],2)
        r=self.service.reopen(s['session_id'],2,self.case,'Explicitly reopen')
        self.assertEqual(r['stage'],'PLAN_REVIEW')

    def test_untrusted_case_bad_methods_and_no_injection(self):
        bad=json.loads(json.dumps(self.case))
        bad['claims'][0]['id']='../../bad'
        out=self.call('start_session',{'case':bad})
        self.assertTrue(out['isError'])
        unknown=self.call('tools/evil',{})
        self.assertTrue(unknown['isError'])
        self.assertEqual(len(TOOLS),18)

    def test_integrity_guard_and_concurrency(self):
        s=self.service.start(self.case)
        with self.service._connect() as db:
            stored=json.loads(db.execute('SELECT session_json FROM sessions WHERE id=?',(s['session_id'],)).fetchone()[0])
            stored['events'][0]['details']['question']='forgery'
            db.execute('UPDATE sessions SET session_json=? WHERE id=?',(json.dumps(stored),s['session_id']))
        with self.assertRaises(ServiceError): self.service.resume(s['session_id'])
        with self.assertRaises(ServiceError): self.service.feedback(s['session_id'],1,'approve','ok')

    def test_persistence_survives_service_restart(self):
        s=self.service.start(self.case)
        svc2=MotifService(self.service.db_path)
        z=svc2.resume(s['session_id'])
        self.assertEqual(z['revision'],1)
        self.assertEqual(z['stage'],'PLAN_REVIEW')

if __name__=='__main__':unittest.main()
