"""MOTIF domain service: SQLite-backed revisioned review checkpoints.

No network, arbitrary-code execution, GitHub mutations, or external effects.
This is a single-owner service: the HTTPS/API key layer protects the principal.
"""
from __future__ import annotations

from contextlib import contextmanager

import importlib.util
import json
import os
from pathlib import Path
import sqlite3
from threading import RLock
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
ENGINE_PATH = ROOT / 'skills' / 'motif-reasoner' / 'scripts' / 'motif.py'
spec = importlib.util.spec_from_file_location('motif_engine_v01', ENGINE_PATH)
assert spec is not None and spec.loader is not None
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)

MAX_NOTE = 2000
MAX_SESSION_COUNT = 2000

class ServiceError(ValueError):
    pass


class MotifService:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.db_path.parent, 0o700)
        except OSError:
            pass
        self.lock = RLock()
        with self._connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                revision INTEGER NOT NULL,
                session_json TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )''')
        try:
            os.chmod(self.db_path, 0o600)
        except OSError:
            pass

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(str(self.db_path), timeout=5)
        try:
            db.execute('PRAGMA busy_timeout=5000')
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _case(raw):
        try:
            return engine.parse_case(raw)
        except (engine.HOLD, ValueError, TypeError, KeyError) as exc:
            raise ServiceError(str(exc)) from exc

    @staticmethod
    def _check_session(s):
        # Recovering a session must validate hash chain, case and routing.
        try:
            if not isinstance(s, dict) or not s.get('events'):
                raise ServiceError('Missing event history')
            case = engine.parse_case(s['case'])
            if case != s['case'] or engine.digest(case) != s['case_sha256']:
                raise ServiceError('Altered case')
            if engine.route(case) != s['routing']:
                raise ServiceError('Altered routing')
            if s['stage'] not in ('PLAN_REVIEW', 'READY', 'RESULT_REVIEW', 'RETURNED', 'HELD'):
                raise ServiceError('Unknown stage')
            prev = '0' * 64
            for index, ev in enumerate(s['events'], 1):
                core = {k: v for k, v in ev.items() if k != 'hash'}
                if ev.get('sequence') != index or ev.get('previous') != prev or engine.digest(core) != ev.get('hash'):
                    raise ServiceError('Altered event history')
                prev = ev['hash']
            if s['stage'] in ('RESULT_REVIEW', 'RETURNED'):
                if not isinstance(s.get('result'), dict):
                    raise ServiceError('Missing computation result')
                run_events = [e for e in s['events'] if e['kind'] == 'BOUNDED_SHARED_CASE_EXECUTION']
                if not run_events or run_events[-1]['details']['result_sha256'] != engine.digest(s['result']):
                    raise ServiceError('Altered computation result')
        except (TypeError, ValueError, KeyError, engine.HOLD) as exc:
            raise ServiceError('Invalid or altered saved session') from exc

    @staticmethod
    def catalog():
        return {'schema': 'motif.mcp.catalog.v1', 'scope': 'EXECUTABLE_BUILTIN_SAME_CASE',
                'method_count': len(engine.METHODS),
                'methods': [{'id': name, 'requires': list(required), 'produces': list(produced),
                             'declared_cost': cost, 'admission': 'BUILTIN_LOCAL_REVIEWED',
                             'source': 'skills/motif-reasoner/scripts/motif.py'}
                            for name, required, produced, cost in engine.METHODS],
                'future_branch_discovery': 'NOT_CONNECTED',
                'ring_002_native_triads': 'NOT_CONNECTED',
                'ring_003_hypergraph': 'NOT_CONNECTED',
                'cross_branch_composition_proven': False,
                'external_actions': False}

    def inspect(self, raw):
        case = self._case(raw)
        return {'inspection': engine.reinspection(case), 'stage': 'UNCOMMITTED_INSPECTION',
                'persisted': False, 'user_review_required': True}

    def _load(self, db, session_id):
        row = db.execute('SELECT revision, session_json FROM sessions WHERE id=?', (session_id,)).fetchone()
        if not row:
            raise ServiceError('Unknown session identifier')
        try:
            s = json.loads(row[1])
        except (TypeError, json.JSONDecodeError) as exc:
            raise ServiceError('Corrupt saved session') from exc
        self._check_session(s)
        return row[0], s

    @staticmethod
    def _receipt(session_id, revision, s):
        result = engine.print_session(s)
        result.update({'session_id': session_id, 'revision': revision,
                       'last_event_hash': s['events'][-1]['hash'],
                       'checkpoints_enforced_by_server': True,
                       'source_owned_evidence_not_automatically_verified': True})
        if s['stage'] == 'RESULT_REVIEW':
            result['reflection'] = MotifService._reflection(s)
        return result

    @staticmethod
    def _reflection(s):
        if not s.get('result'):
            return {'status': 'NO_EXECUTION_TO_EVALUATE', 'question': 'What evidence is missing?'}
        out = s['result']['outputs']
        conflicts = out.get('conflicts', {}).get('conflicting_topics', [])
        questions = out.get('questions', {}).get('next_questions', [])
        blocked = out.get('frontier', {}).get('remaining_blockers', [])
        missing = s['routing']['missing']
        if conflicts:
            next_q = questions[0] if questions else 'What independent evidence would resolve conflicting claims?'
            why = 'Reported conflicts remain unresolved; this is not an adjudicated answer.'
        elif blocked:
            next_q = 'Which missing prerequisite is actually available or could be verified?'
            why = 'Hypothetical execution remains blocked by capabilities.'
        elif missing:
            next_q = 'Which missing output matters most to the human?'
            why = 'Not all declared goals were covered.'
        else:
            next_q = 'Did this result help solve the original real-world question? What would change the plan?'
            why = 'Declared goal coverage is not observed task improvement.'
        return {'status': 'REINSPECTION_RECOMMENDED', 'reason': why,
                'next_human_question': next_q, 'competing_claim_topics': len(conflicts),
                'blocked_hypothetical_actions': len(blocked),
                'routed_goal_coverage': len(s['routing']['covered']),
                'baseline_is_only_declared_goal_coverage': True,
                'learning_signal': 'AWAIT_REAL_HUMAN_FEEDBACK',
                'autorun_next_cycle': False}

    def start(self, raw):
        case = self._case(raw)
        inspect = engine.reinspection(case)
        s = {'schema': engine.SCHEMA, 'stage': 'PLAN_REVIEW', 'cycle': 1,
             'case': case, 'case_sha256': engine.digest(case),
             'routing': inspect['routing'], 'events': []}
        engine.event(s, 'REINSPECT_AND_ROUTE', inspect)
        session_id = str(uuid4())
        with self.lock, self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT COUNT(*) FROM sessions').fetchone()[0] >= MAX_SESSION_COUNT:
                raise ServiceError('Session quota reached; export or archive old sessions')
            db.execute('INSERT INTO sessions(id,revision,session_json) VALUES(?,?,?)',
                       (session_id, 1, engine.canonical(s)))
        return self._receipt(session_id, 1, s)

    def list_sessions(self, limit=20):
        if type(limit) is not int or not 1 <= limit <= 30:
            raise ServiceError('Limit must be between 1 and 30')
        with self.lock, self._connect() as db:
            rows = db.execute("SELECT id, revision, session_json, updated_at "
                              "FROM sessions ORDER BY updated_at DESC, rowid DESC LIMIT ?",
                              (limit,)).fetchall()
        items=[]
        for sid, rev, raw, when in rows:
            try:
                s=json.loads(raw)
                self._check_session(s)
                items.append({'session_id':sid,'revision':rev,'stage':s['stage'],
                              'cycle':s['cycle'],'question':s['case']['question'][:250],
                              'last_event_kind':s['events'][-1]['kind'], 'updated_at':when})
            except (ValueError, KeyError, TypeError):
                items.append({'session_id':sid,'status':'CORRUPT_HOLD'})
        return {'sessions':items,'returned_count':len(items),'limit':limit,
                'account_scope':'PERSONAL_API_KEY_PROTECTED_DB'}

    def resume(self, session_id):
        with self.lock, self._connect() as db:
            revision, s = self._load(db, session_id)
        return self._receipt(session_id, revision, s)

    def _mutate(self, session_id, expected_revision, action):
        if type(expected_revision) is not int or expected_revision < 1:
            raise ServiceError('Expected revision must be positive integer')
        with self.lock, self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            revision, s = self._load(db, session_id)
            if revision != expected_revision:
                raise ServiceError('STALE_REVISION: resume and reinspect before attempting a write')
            action(s)
            self._check_session(s)
            new_revision = revision + 1
            db.execute('UPDATE sessions SET revision=?,session_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                       (new_revision, engine.canonical(s), session_id))
        return self._receipt(session_id, new_revision, s)

    def feedback(self, session_id, expected_revision, decision, review_note,
                 updated_case=None, observed_outcome=''):
        if decision not in ('approve', 'accept', 'revise', 'hold'):
            raise ServiceError('Unknown human review decision')
        if not isinstance(review_note, str) or not review_note.strip() or len(review_note)>MAX_NOTE:
            raise ServiceError('Human review needs nonempty bounded note')
        if not isinstance(observed_outcome, str) or len(observed_outcome)>MAX_NOTE:
            raise ServiceError('Invalid outcome note')
        def act(s):
            stage=s['stage']
            if decision == 'approve' and stage == 'PLAN_REVIEW':
                if s['routing']['missing']:
                    raise ServiceError('Goals uncovered; cannot approve route')
                s['stage']='READY'
                engine.event(s,'HUMAN_APPROVED_ROUTING',{'note':review_note,
                                                        'attestation_is_client_report_not_verified_identity':True})
            elif decision == 'accept' and stage == 'RESULT_REVIEW':
                s['stage']='RETURNED'
                engine.event(s,'HUMAN_RETURNED',{'note':review_note, 'observed_outcome':observed_outcome,
                                                 'outcome_is_unverified_user_report':True})
            elif decision == 'hold' and stage in ('PLAN_REVIEW','RESULT_REVIEW'):
                s['stage']='HELD'
                engine.event(s,'HUMAN_HELD',{'note':review_note})
            elif decision == 'revise' and stage in ('PLAN_REVIEW','RESULT_REVIEW'):
                if updated_case is None:
                    raise ServiceError('Revising requires an explicit updated typed case')
                case=self._case(updated_case)
                s['case']=case
                s['case_sha256']=engine.digest(case)
                s['routing']=engine.route(case)
                s.pop('result',None)
                s['cycle']+=1
                s['stage']='PLAN_REVIEW'
                engine.event(s,'REINSPECT_AND_REPLAN',{'note':review_note,'inspection':engine.reinspection(case)})
            else:
                raise ServiceError('Decision not allowed at this review checkpoint')
        return self._mutate(session_id, expected_revision, act)

    def execute(self, session_id, expected_revision):
        def act(s):
            if s['stage'] != 'READY':
                raise ServiceError('Routing must receive explicit human approval first')
            s['result'] = engine.run(s['case'],s['routing'])
            s['stage']='RESULT_REVIEW'
            engine.event(s,'BOUNDED_SHARED_CASE_EXECUTION',{'result_sha256':engine.digest(s['result']),
                                                            'methods':s['routing']['selected']})
        return self._mutate(session_id,expected_revision,act)

    def reopen(self, session_id, expected_revision, updated_case, review_note):
        if not isinstance(review_note,str) or not review_note.strip() or len(review_note)>MAX_NOTE:
            raise ServiceError('Reopen requires a bounded review note')
        case=self._case(updated_case)
        def act(s):
            if s['stage'] not in ('RETURNED','HELD'):
                raise ServiceError('Only a returned or held session can be reopened')
            s['cycle']+=1
            s['case']=case
            s['case_sha256']=engine.digest(case)
            s['routing']=engine.route(case)
            s.pop('result',None)
            s['stage']='PLAN_REVIEW'
            engine.event(s,'REOPEN_AND_REINSPECT',{'note':review_note,'inspection':engine.reinspection(case)})
        return self._mutate(session_id,expected_revision,act)
