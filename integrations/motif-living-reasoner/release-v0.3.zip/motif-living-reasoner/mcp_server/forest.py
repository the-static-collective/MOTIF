"""MOTIF forest v0.3: source-pinned discovery, RING-003-compatible routing,
reviewed RING-002/004 native runs, and persistent human return checkpoints.

The forest distinguishes indexed source refs from THREE approved native methods.
Live source indexing never grants execution. Experimental runs require Docker,
pinned complete checkout and explicit review. No host fallback or arbitrary refs.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
from hashlib import sha1, sha256
from itertools import combinations
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import tempfile
from threading import RLock
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
from uuid import uuid4

REPOSITORY = "the-static-collective/MOTIF"
API = f"https://api.github.com/repos/{REPOSITORY}"
RING003 = "9e4fc10c02e09f8e4507ab33994bc2a3115cc3b8"
RING004 = "86a0c797bc797e895cf7d17727f34b044a532f30"
RESEARCH_BRANCH = "experiment/cartridge-ring-004-shared-evidence-trial"
PINS = {
    "geometry.procedure-repair": "a3dc551ababa40c29975c9b54c4eaa515d9dc18c",
    "thought.language-dev": "a38c617641adffe52cd4df283996a58f0fe7b973",
    "reason.proof-objection": "d0808c6a829fc6ef15d736c325790ddb4d169ab1",
}
METHODS = tuple(sorted(PINS))
# Exact RING-003 current_graph declared edges; unvalidated design hypotheses.
EDGES = (
    ("geometry.many-uses", ("geometry.procedure-repair",), ("measurement-revision", "duplicate-record-audit", "procedure-counterexample-question"), 0),
    ("reason.many-uses", ("reason.proof-objection",), ("proof-review", "objection-review", "question-proposal"), 0),
    ("language.many-uses", ("thought.language-dev",), ("utterance-classification", "language-rule-audit", "ambiguity-question"), 0),
    ("language-and-reason.joint-bridge", ("thought.language-dev", "reason.proof-objection"), ("interpretation-objection-bridge", "language-evidence-skepticism"), 0),
    ("geometry-and-reason.joint-bridge", ("geometry.procedure-repair", "reason.proof-objection"), ("measurement-proof-challenge", "procedure-counterexample-bridge"), 0),
    ("language-and-geometry.joint-bridge", ("geometry.procedure-repair", "thought.language-dev"), ("measurement-description-check",), 0),
    ("all-three.joint-bridge", ("geometry.procedure-repair", "thought.language-dev", "reason.proof-objection"), ("cross-instrument-evidence-review", "explain-measurement-objection"), 0),
    ("geometry-language.unsupported-crossworld", ("geometry.procedure-repair", "thought.language-dev"), ("crossworld-scope-risk",), 3),
)
GOALS = sorted({x for _,_,heads,penalty in EDGES if not penalty for x in heads})
NAME = re.compile(r"^(?!/)(?!.*\.\.)(?!.*//)[A-Za-z0-9][A-Za-z0-9._/-]{0,159}$")
SHA = re.compile(r"[0-9a-f]{40}")
MAX_SOURCE_BYTES = 60_000
MAX_BRANCHES = 2000
MAX_NOTE = 2000

class ForestError(ValueError):
    pass

def canon(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)

def digest(data):
    return sha256(canon(data).encode()).hexdigest()

def valid_ref(ref):
    return type(ref) is str and NAME.fullmatch(ref) and not ref.endswith("/") and not ref.startswith("-")

def validate_goals(goals, budget, max_methods):
    if (type(goals) is not dict or not goals or len(goals)>20 or any(
        type(k) is not str or k not in GOALS or type(v) is not int or not 1<=v<=100
        for k,v in goals.items())):
        raise ForestError("Specify one or more typed RING-003 goal weights from available_goals")
    if type(budget) is not int or not 0<=budget<=12:
        raise ForestError("Budget outside 0..12")
    if type(max_methods) is not int or not 0<=max_methods<=3:
        raise ForestError("Max methods outside 0..3")

def evaluate(chosen, goals):
    active=[(name,heads,penalty) for name,tails,heads,penalty in EDGES if set(tails)<=set(chosen)]
    produces={head for _,heads,p in active if p==0 for head in heads}
    covered=sorted(set(goals)&produces)
    missing=sorted(set(goals)-produces)
    cost=2*len(chosen)
    penalty=sum(p for _,_,p in active)
    benefit=sum(goals[g] for g in covered)
    return {"selected":list(chosen),"covered":covered,"missing":missing,
        "declared_benefit":benefit,"declared_cost":cost,
        "declared_tension_penalty":penalty,"declared_net_utility":benefit-cost-penalty,
        "triggered_hyperedges":[n for n,_,_ in active],
        "coverage_is_not_evidence_of_task_success":True}

def route(goals, budget=6, max_methods=3):
    validate_goals(goals,budget,max_methods)
    choices=[]
    for r in range(max_methods+1):
        for combo in combinations(METHODS,r):
            e=evaluate(combo,goals)
            if e["declared_cost"]<=budget:choices.append(e)
    choices.sort(key=lambda e:(-e["declared_net_utility"],-e["declared_benefit"],
        e["declared_cost"],e["declared_tension_penalty"],len(e["selected"]),e["selected"]))
    best=choices[0]
    # RING-003's greedy single-addition comparator, including multi-tail synergy.
    chosen=()
    while len(chosen)<max_methods:
        curr=evaluate(chosen,goals)
        nexts=[evaluate(tuple(sorted(chosen+(m,))),goals) for m in METHODS if m not in chosen]
        nexts=[r for r in nexts if r["declared_cost"]<=budget and r["declared_net_utility"]>curr["declared_net_utility"]]
        if not nexts:break
        nexts.sort(key=lambda x:(-x["declared_net_utility"],x["declared_cost"],x["selected"]))
        chosen=tuple(nexts[0]["selected"])
    result={"schema":"motif.cartridge-hypergraph-selection.v1",
        "source":"RING-003 exact finite declared-utility subset policy transcribed from pinned source",
        "source_commit":RING003,"goals":goals,"declared_budget":budget,
        "max_methods":max_methods,"selected":best,"all_goals_covered":not best["missing"],
        "subsets_evaluated":len(choices),"baselines":{
            "greedy_single_addition":evaluate(chosen,goals),
            "always_all_if_budgeted":evaluate(METHODS,goals) if len(METHODS)<=max_methods and 6<=budget else {"status":"NOT_FEASIBLE_UNDER_DECLARED_BUDGET"}},
        "joint_task_success_measured":False,
        "design_hypotheses_not_empirical_capabilities":True,
        "source_only_future_branches_auto_executable":False,
        "real_world_authority":False}
    result["receipt_sha256"]=digest(result)
    return result


def github_request(url, *, token=None):
    """Fixed GitHub API host only; no user-supplied URLs or arbitrary redirects."""
    if not url.startswith(API+'/'):
        raise ForestError("Unknown source host")
    headers={"Accept":"application/vnd.github+json", "User-Agent":"MOTIF-Forest-MCP/0.3"}
    credential=token if token is not None else os.getenv("MOTIF_GITHUB_READ_TOKEN")
    if credential:headers["Authorization"]="Bearer "+credential
    request=Request(url,headers=headers,method="GET")
    try:
        with urlopen(request,timeout=12) as response:
            if response.geturl().split('/')[2]!="api.github.com":
                raise ForestError("Redirected outside fixed GitHub API")
            raw=response.read(1_100_000)
            if len(raw)>1_000_000:raise ForestError("GitHub response too large")
    except (HTTPError,URLError,TimeoutError,OSError) as exc:
        raise ForestError("GitHub unavailable or rate-limited; existing snapshot retained") from exc
    try:return json.loads(raw)
    except (ValueError,UnicodeError) as exc:raise ForestError("Malformed GitHub JSON") from exc

def scan(fetch=github_request):
    result=[]
    for page in range(1,21):
        rows=fetch(f"{API}/branches?per_page=100&page={page}")
        if type(rows) is not list:raise ForestError("Branch scan was not a list")
        for row in rows:
            name=row.get("name") if isinstance(row,dict) else None
            commit=row.get("commit") if isinstance(row,dict) else None
            sha=commit.get("sha") if isinstance(commit,dict) else None
            if not valid_ref(name) or type(sha) is not str or not SHA.fullmatch(sha):
                raise ForestError("Malformed or unsafe source passport")
            result.append({"ref":name,"commit":sha,
                           "state":"INDEXED_NON_EXECUTABLE", "executable":False})
        if len(result)>MAX_BRANCHES:raise ForestError("Branch scan exceeds safety cap")
        if len(rows)<100:break
    else:raise ForestError("Branch scan reached pagination cap; completeness unverified")
    refs=[r["ref"] for r in result]
    if len(set(refs))!=len(refs):raise ForestError("Repeated branch names")
    return {"schema":"motif.branch-garden.v3","repo":REPOSITORY,
        "passports":sorted(result,key=lambda x:x["ref"]),
        "complete_under_api_pagination":True,"indexed_count":len(result),
        "indexed_branch_execution_granted":False}

def pinned_source(passports, ref, path, fetch=github_request):
    if not valid_ref(ref) or ref not in {r["ref"] for r in passports}:
        raise ForestError("Unknown indexed branch")
    if (type(path) is not str or len(path)>230 or not valid_ref(path)
        or (not path.startswith('experiments/') and not path.startswith('docs/')
            and path!='README.md') or path.endswith('/')):
        raise ForestError("Source inspection restricted to documented text paths")
    sha=next(p["commit"] for p in passports if p["ref"]==ref)
    data=fetch(f"{API}/contents/{quote(path,safe='/')}?ref={sha}")
    if not isinstance(data,dict) or data.get('type')!='file' or data.get('encoding')!='base64':
        raise ForestError("Source text unavailable or not a file")
    content=data.get('content')
    if type(content) is not str or len(content)>MAX_SOURCE_BYTES*2:
        raise ForestError("Source file too large")
    try:
        payload=base64.b64decode(content,validate=False)
        raw=payload.decode('utf-8')
    except (ValueError,UnicodeError) as exc:
        raise ForestError("Source file is not UTF-8 text") from exc
    if len(payload)>MAX_SOURCE_BYTES or b'\0' in payload:
        raise ForestError("Only bounded source text may be inspected")
    blob=sha1(("blob %s\0"%len(payload)).encode()+payload).hexdigest()
    if data.get('sha')!=blob:raise ForestError("Fetched source blob hash mismatch")
    return {"ref":ref,"source_commit":sha,"path":path,"source_blob_sha1":blob,
        "lines":len(raw.splitlines()),"text":raw,"executable":False,"inspected_source_not_admitted":True}

class NativeRunner:
    """Only pinned RING-002/004 controllers, never a dynamic source branch."""
    def __init__(self, repo_root=None, image=None):
        self.repo_root=Path(repo_root or os.getenv('MOTIF_CHECKOUT','/opt/motif')).expanduser()
        self.image=image or os.getenv('MOTIF_DOCKER_IMAGE','python:3.11-slim')

    def _check(self):
        if not shutil.which('docker'):
            raise ForestError("Docker unavailable; native trial held, no unsafe host fallback")
        if not (self.repo_root/'.git').exists() and not (self.repo_root/'.git').is_file():
            raise ForestError("A full pinned MOTIF git checkout is required")
        for sha in (RING004,RING003,*PINS.values()):
            p=subprocess.run(['git','cat-file','-e',sha+'^{commit}'],cwd=self.repo_root,
                             capture_output=True,timeout=10,check=False)
            if p.returncode:
                raise ForestError('Missing pinned research git commit; fetch full history before trial')

    def run(self, kind, selected, seed, count):
        self._check()
        with tempfile.TemporaryDirectory(prefix='motif-native-forest-') as tmp:
            root=Path(tmp)/'source'
            p=subprocess.run(['git','worktree','add','--detach',str(root),RING004],cwd=self.repo_root,
                             capture_output=True,timeout=30,check=False)
            if p.returncode:raise ForestError('Unable to create pinned research worktree')
            try:
                out=Path(tmp)/'trial.json'
                if kind=='shared_world_004':
                    cmd=['python','experiments/cartridge-ring-004/comparator.py',
                         '--repo-root',str(self.repo_root),'--seed',str(seed),
                         '--count',str(count),'--image',self.image,'--out',str(out)]
                elif kind=='native_triad_002':
                    cmd=['python','experiments/cartridge-ring-001/triad.py',
                         '--repo-root',str(self.repo_root),'--select',*selected,
                         '--image',self.image,'--output',str(out)]
                else:raise ForestError('Unknown pinned native research trial')
                try:
                    p=subprocess.run(cmd,cwd=root,capture_output=True,timeout=220,check=False,
                                    env={'PATH':os.environ.get('PATH','/usr/bin:/bin'), 'LANG':'C.UTF-8'})
                except (subprocess.TimeoutExpired,OSError) as exc:
                    raise ForestError('Pinned research controller timed out or failed') from exc
                if p.returncode or not out.is_file() or out.stat().st_size>2_000_000:
                    raise ForestError('Pinned research controller refused, failed or oversized output')
                report=json.loads(out.read_text())
                if kind=='shared_world_004':
                    if (report.get('schema')!='motif.shared-evidence-benchmark.v1' or
                        report.get('count')!=count or report.get('external_action_executed') is not False or
                        report.get('real_world_authority') is not False or
                        report.get('status')!='SOURCE_NATIVE_COMMON_WORLD_SYNTHETIC_EVALUATION'):
                        raise ForestError('Invalid shared-world source-native receipt')
                else:
                    if (report.get('schema')!='motif.triad-adapter-receipt.v1' or
                        report.get('external_action_executed') is not False or
                        report.get('selected')!=sorted(selected) or
                        report.get('cross_method_compatibility')!='UNPROVEN'):
                        raise ForestError('Invalid isolated triad receipt')
                recorded=report.pop('receipt_sha256',None)
                if recorded!=digest(report):raise ForestError('Research receipt digest mismatch')
                report['receipt_sha256']=recorded
                return report
            finally:
                subprocess.run(['git','worktree','remove','--force',str(root)],
                               cwd=self.repo_root,capture_output=True,timeout=20,check=False)

class ForestService:
    def __init__(self,db_path, *, runner=None, fetch=github_request):
        self.path=str(db_path)
        self.fetch=fetch
        self.runner=runner or NativeRunner()
        self.lock=RLock()
        Path(self.path).parent.mkdir(parents=True,exist_ok=True)
        with self._conn() as db:
            db.execute('CREATE TABLE IF NOT EXISTS forest_snapshots(id TEXT PRIMARY KEY, body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
            db.execute('CREATE TABLE IF NOT EXISTS forest_trials(id TEXT PRIMARY KEY, revision INTEGER NOT NULL, body TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')

    @contextmanager
    def _conn(self):
        db=sqlite3.connect(self.path, timeout=5)
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def catalog(self,refresh=False, offset=0, limit=30):
        if type(refresh) is not bool or type(offset) is not int or offset<0 or type(limit) is not int or not 1<=limit<=100:
            raise ForestError('Invalid forest pagination')
        with self.lock, self._conn() as db:
            row=db.execute('SELECT id,body,created_at FROM forest_snapshots ORDER BY rowid DESC LIMIT 1').fetchone()
            if row is None or refresh:
                # Fail closed: leave the last complete snapshot available if refresh fails.
                snapshot=scan(self.fetch)
                sid=digest(snapshot)
                db.execute('INSERT OR IGNORE INTO forest_snapshots(id,body) VALUES(?,?)',(sid,canon(snapshot)))
                db.commit()
                row=db.execute('SELECT id,body,created_at FROM forest_snapshots WHERE id=?',(sid,)).fetchone()
            snap=json.loads(row[1])
        passports=snap['passports']
        return {'snapshot_id':row[0],'captured_at':row[2],'total':len(passports),
                'offset':offset,'next_offset':offset+limit if offset+limit<len(passports) else None,
                'passports':passports[offset:offset+limit], 'all_indexed_are_non_executable':True,
                'native_admitted_methods':list(METHODS),'research_pins':{'ring003':RING003,'ring004':RING004},
                'completed_live_scan':True}

    def source(self,snapshot_id,ref,path):
        if not isinstance(snapshot_id,str) or not SHA.fullmatch(snapshot_id[:40]) or len(snapshot_id)!=64:
            raise ForestError('Bad snapshot id')
        with self.lock,self._conn() as db:
            row=db.execute('SELECT body FROM forest_snapshots WHERE id=?',(snapshot_id,)).fetchone()
        if row is None:raise ForestError('Unknown source snapshot; run forest_catalog')
        snap=json.loads(row[0])
        if digest(snap)!=snapshot_id:raise ForestError('Altered source snapshot')
        return pinned_source(snap['passports'],ref,path,self.fetch)

    @staticmethod
    def _trial_request(goals,budget,max_methods,kind,seed,count):
        plan=route(goals,budget,max_methods)
        if kind not in ('shared_world_004','native_triad_002'):
            raise ForestError('Unknown trial kind')
        if type(seed) is not int or not 0<=seed<2**32 or type(count) is not int or not 1<=count<=32:
            raise ForestError('Trial seed/count outside audited limits')
        selection=plan['selected']['selected']
        if plan['selected']['missing']:
            raise ForestError('Uncovered requested goals: revise plan')
        if kind=='shared_world_004' and set(selection)!=set(METHODS):
            raise ForestError('RING-004 joint trial requires all three original native methods')
        return {'kind':kind,'seed':seed,'count':count,'plan':plan,'selected':selection}

    def start(self,goals,budget=6,max_methods=3,kind='shared_world_004',seed=2026110615,count=8):
        req=self._trial_request(goals,budget,max_methods,kind,seed,count)
        session={'schema':'motif.forest-trial.v1','stage':'PLAN_REVIEW','cycle':1,
                 'request':req,'events':[], 'result':None}
        self._event(session,'FOREST_ROUTED',{'request_sha256':digest(req)})
        sid=str(uuid4())
        with self.lock,self._conn() as db:
            db.execute('INSERT INTO forest_trials(id,revision,body) VALUES(?,?,?)',(sid,1,canon(session)))
            db.commit()
        return self._present(sid,1,session)

    @staticmethod
    def _event(s,kind,details):
        if len(s['events'])>=40:raise ForestError('Forest event quota exceeded')
        prev=s['events'][-1]['hash'] if s['events'] else '0'*64
        ev={'kind':kind,'details':details,'index':len(s['events'])+1,'previous':prev}
        ev['hash']=digest(ev)
        s['events'].append(ev)

    @classmethod
    def _check(cls,s):
        if s.get('schema')!='motif.forest-trial.v1' or s.get('stage') not in ('PLAN_REVIEW','READY','RESULT_REVIEW','RETURNED','HELD'):
            raise ForestError('Unknown forest session schema or stage')
        req=s['request']
        if req!=cls._trial_request(req['plan']['goals'],req['plan']['declared_budget'],
                                  req['plan']['max_methods'],req['kind'],req['seed'],req['count']):
            raise ForestError('Forest trial request was altered')
        prev='0'*64
        for i,ev in enumerate(s['events'],1):
            if ev.get('index')!=i or ev.get('previous')!=prev or ev.get('hash')!=digest({k:v for k,v in ev.items() if k!='hash'}):
                raise ForestError('Broken forest event chain')
            prev=ev['hash']
        if s.get('result') is not None:
            result=s['result']
            if result.get('receipt_sha256')!=digest({k:v for k,v in result.items() if k!='receipt_sha256'}):
                raise ForestError('Forest result digest mismatch')

    @staticmethod
    def _reflection(s):
        if s['stage']=='PLAN_REVIEW':
            return {'next_question':'Does this source-native synthetic trial match the problem you want to investigate?',
                    'requires_human_decision':True}
        if s['stage']=='READY':
            return {'next_question':'Run the approved bounded experiment?', 'requires_human_decision':False}
        if s['result'] is None:
            return {'next_question':'What evidence would revise this held plan?', 'requires_human_decision':True}
        if s['request']['kind']=='shared_world_004':
            return {'next_question':'Which independently authored real-world case should challenge this synthetic composition and its strong classical baseline?',
                    'research_limit':'Results on generated XOR graph cases are not external validity.',
                    'requires_human_decision':True}
        return {'next_question':'What ONE shared evidence packet would let these individually runnable native methods exchange and contest conclusions?',
                'research_limit':'RING-002 triad original demos are separate synthetic worlds.',
                'requires_human_decision':True}

    @classmethod
    def _present(cls,sid,rev,s):
        return {'session_id':sid,'revision':rev,'stage':s['stage'],'cycle':s['cycle'],
                'plan':s['request']['plan'],'kind':s['request']['kind'],
                'research_source_commit':RING004,'result':s['result'],
                'reflection':cls._reflection(s),'last_event_hash':s['events'][-1]['hash'],
                'no_external_actions':True,'human_return_required':True}

    def _load(self,db,sid):
        row=db.execute('SELECT revision,body FROM forest_trials WHERE id=?',(sid,)).fetchone()
        if row is None:raise ForestError('Unknown forest trial ID')
        s=json.loads(row[1]);self._check(s)
        return row[0],s

    def resume(self,sid):
        with self.lock,self._conn() as db:
            rev,s=self._load(db,sid)
        return self._present(sid,rev,s)

    def _mutate(self,sid,rev,apply):
        if type(rev) is not int or rev<1:raise ForestError('Bad expected revision')
        with self.lock,self._conn() as db:
            db.execute('BEGIN IMMEDIATE')
            actual,s=self._load(db,sid)
            if actual!=rev:raise ForestError('STALE_REVISION: resume before changing a forest trial')
            apply(s)
            self._check(s)
            db.execute('UPDATE forest_trials SET revision=?,body=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                       (rev+1,canon(s),sid));db.commit()
        return self._present(sid,rev+1,s)

    def feedback(self,sid,rev,decision,note):
        if decision not in ('approve','accept','hold'):
            raise ForestError('Forest feedback allows approve, accept or hold; revise by creating a new route')
        if not isinstance(note,str) or not note.strip() or len(note)>MAX_NOTE:
            raise ForestError('Bounded human review note required')
        def act(s):
            if decision=='approve' and s['stage']=='PLAN_REVIEW':
                s['stage']='READY';self._event(s,'HUMAN_PLAN_APPROVAL_REPORTED',{'note':note})
            elif decision=='accept' and s['stage']=='RESULT_REVIEW':
                s['stage']='RETURNED';self._event(s,'HUMAN_RESULT_REVIEW_REPORTED',{'note':note})
            elif decision=='hold' and s['stage'] in ('PLAN_REVIEW','RESULT_REVIEW'):
                s['stage']='HELD';self._event(s,'HUMAN_HOLD_REPORTED',{'note':note})
            else:raise ForestError('Feedback conflicts with current checkpoint')
        return self._mutate(sid,rev,act)

    def execute(self,sid,rev):
        # Hold the single-user lock to serialize consent+execution; never execute
        # on a stale revision. The pinned controller itself is isolated by design.
        def act(s):
            if s['stage']!='READY':raise ForestError('Human-approved plan required')
            req=s['request']
            s['result']=self.runner.run(req['kind'],req['selected'],req['seed'],req['count'])
            s['stage']='RESULT_REVIEW'
            self._event(s,'REVIEWED_SOURCE_NATIVE_RESEARCH',{'sha256':s['result']['receipt_sha256'],
                    'kind':req['kind'],'original_source_pins':PINS})
        return self._mutate(sid,rev,act)

    def list_trials(self,limit=15):
        if type(limit) is not int or not 1<=limit<=30:raise ForestError('Bad limit')
        with self.lock,self._conn() as db:
            rows=db.execute('SELECT id,revision,body FROM forest_trials ORDER BY updated_at DESC,rowid DESC LIMIT ?',
                            (limit,)).fetchall()
        items=[]
        for sid,rev,raw in rows:
            s=json.loads(raw)
            try:self._check(s)
            except ForestError:items.append({'id':sid,'stage':'CORRUPT_HOLD'});continue
            items.append({'id':sid,'revision':rev,'stage':s['stage'],'kind':s['request']['kind'],
                          'selected':s['request']['selected']})
        return {'trials':items,'count':len(items)}
