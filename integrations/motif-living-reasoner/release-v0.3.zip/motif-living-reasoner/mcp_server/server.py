"""Small dependency-light MCP Streamable HTTP/stdio tool host.

Uses the 2025-06-18 JSON-RPC subset required by this no-streaming tool server.
It deliberately does NOT offer SSE subscriptions, elicitation, sampling,
resources, multi-user OAuth, or a general-purpose code executor.
"""
from __future__ import annotations

import hmac
import json
import os
from pathlib import Path
import sys
import time
from collections import defaultdict, deque

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

from .service import MotifService, ServiceError
from .forest import ForestService, ForestError, GOALS as FOREST_GOALS, METHODS as FOREST_METHODS, route as forest_route

NAME = 'motif-living-reasoner'
VERSION = '0.3.0'
PROTOCOL = '2025-06-18'
DEFAULT_DB = Path.home() / '.local' / 'share' / 'motif-living-reasoner' / 'sessions.sqlite3'


def arg(name, description='', *, required=True, schema=None):
    return (name, schema or {'type': 'string', 'description': description}, required)


def tool(name, description, *fields, read_only=False):
    props = {n: s for n, s, _ in fields}
    required = [n for n, _, yes in fields if yes]
    return {'name': name, 'description': description,
            'inputSchema': {'type': 'object', 'properties': props,
                            'required': required, 'additionalProperties': False},
            'annotations': {'readOnlyHint': read_only, 'destructiveHint': False,
                            'openWorldHint': False}}

CASE = {'type':'object', 'description':'Typed case: question, goals, claims, actions, available, budget, action_budget. Read skills/motif-reasoner/references/CASE.md.'}
SID = arg('session_id', 'Opaque UUID returned by start_session')
REV = arg('expected_revision', 'Exact current revision; reject stale writes',schema={'type':'integer','minimum':1})
NOTE = arg('review_note', 'Substantive explicit human feedback or correction (not generated approval)')

TOOLS = [
    tool('catalog_cartridges','Read the executable local six-cartridge catalog and explicitly report missing experimental native adapters.',read_only=True),
    tool('select_methods','Inspect a typed case and run exact, bounded dependency-aware cartridge selection, without creating a session.',arg('case',schema=CASE),read_only=True),
    tool('start_session','Start a durable collaborative reasoning session and STOP at PLAN_REVIEW. Present proposed route and ask human for a review.',arg('case',schema=CASE)),
    tool('resume_session','Retrieve a session, stage, revision, last result and next checkpoint without modifying it.',SID,read_only=True),
    tool('list_sessions','Find the most recently updated session IDs and checkpoint stages for returning across conversations.',arg('limit',required=False,schema={'type':'integer','minimum':1,'maximum':30}),read_only=True),
    tool('record_feedback','Record actual human plan approval, result acceptance, explicit correction or HOLD. Only call with user-provided approval/feedback. For revise, include updated_case; never fabricate assent.',SID,REV,arg('decision',schema={'type':'string','enum':['approve','accept','revise','hold']}),NOTE,arg('updated_case',required=False,schema=CASE),arg('observed_outcome',required=False,description='Only user-reported outcome; no verification implied')),
    tool('execute_reviewed','Execute the finite selected six-cartridge common-case plan only after a recorded PLAN_REVIEW approval. Stops at RESULT_REVIEW, which must return to the human.',SID,REV),
    tool('reopen_session','Start a revised cycle after prior return or HOLD; MUST provide a revised typed case and go through PLAN_REVIEW again.',SID,REV,arg('updated_case',schema=CASE),NOTE),
    tool('reflect_session','Read the checkpoint and propose ONE concrete next human question, without executing more work.',SID,read_only=True),
]
# Experimental forest: source-only passports + three pinned admitted native methods.
# Source refs can be inspected, but never executed by selecting their branch name.
FOREST_GOAL_SCHEMA = {'type':'object','description':'RING-003 typed {goal: integer weight}; available via forest_goals.',
                      'additionalProperties': {'type':'integer','minimum':1,'maximum':100}}
FOREST_GOALS_ARG=arg('goals',schema=FOREST_GOAL_SCHEMA)
FSESSION=arg('forest_session_id','Opaque forest trial UUID')
KIND=arg('kind',required=False,schema={'type':'string','enum':['shared_world_004','native_triad_002']})
FOREST_COMMON=(FOREST_GOALS_ARG,
    arg('budget',required=False,schema={'type':'integer','minimum':0,'maximum':12}),
    arg('max_methods',required=False,schema={'type':'integer','minimum':0,'maximum':3}))
TOOLS.extend([
    tool('forest_goals','Read RING-003 source-pinned native methods, typed goals, evidence/authority limitations. Use to choose explicit task goals.',read_only=True),
    tool('forest_catalog','Discover ALL accessible MOTIF branches from GitHub with source SHA passports, or page a complete cached snapshot. No newly discovered branch is executable.',
         arg('refresh',required=False,schema={'type':'boolean'}),
         arg('offset',required=False,schema={'type':'integer','minimum':0}),
         arg('limit',required=False,schema={'type':'integer','minimum':1,'maximum':100}),read_only=True),
    tool('forest_inspect_source','Read a UTF-8 GitHub source file by a CACHED branch snapshot and exact commit. Source-only; never imports or executes its contents.',
         arg('snapshot_id'),arg('ref'),arg('path'),read_only=True),
    tool('forest_route','Calculate a RING-003 finite, multi-tail hypergraph selection under a budget. Edge benefits are DECLARED, not observed successful task utility.',*FOREST_COMMON,read_only=True),
    tool('forest_start_trial','Create a durable RING-002 or RING-004 research trial, stopping at PLAN_REVIEW. RING-004 needs all 3 native methods, and native trials require pinned Git checkout + Docker.',
         *FOREST_COMMON,KIND,
         arg('seed',required=False,schema={'type':'integer','minimum':0,'maximum':4294967295}),
         arg('count',required=False,schema={'type':'integer','minimum':1,'maximum':32})),
    tool('forest_resume_trial','Recover a pinned native research trial and its pending human checkpoint.',FSESSION,read_only=True),
    tool('forest_list_trials','Find earlier forest trials to return to in subsequent conversations.',arg('limit',required=False,schema={'type':'integer','minimum':1,'maximum':30}),read_only=True),
    tool('forest_feedback','Record human approval, acceptance or HOLD at the actual review checkpoint. Never fabricate assent.',
         FSESSION,REV,arg('decision',schema={'type':'string','enum':['approve','accept','hold']}),NOTE),
    tool('forest_execute_reviewed','Run reviewed, PINNED RING-002 triad or RING-004 common-world benchmark inside a Docker no-network sandbox. No host fallback, dynamic branch execution or external effects.',FSESSION,REV),
])
TOOL_NAMES = {x['name'] for x in TOOLS}


def dispatch(service, name: str, args: dict):
    if not isinstance(args,dict) or name not in TOOL_NAMES:
        raise ServiceError('Unknown tool or malformed arguments')
    allowed=set(next(t['inputSchema']['properties'] for t in TOOLS if t['name']==name))
    if set(args)-allowed:
        raise ServiceError('Unexpected tool arguments')
    required=set(next(t['inputSchema']['required'] for t in TOOLS if t['name']==name))
    if not required <= set(args):
        raise ServiceError('Missing required tool arguments')
    if name.startswith('forest_'):
        if not hasattr(service,'forest'):
            service.forest=ForestService(service.db_path)
        f=service.forest
        if name=='forest_goals':
            return {'goals':FOREST_GOALS,'native_methods':list(FOREST_METHODS),
                    'selection_basis':'RING-003 pinned declared multi-tail affordance hypotheses',
                    'source_only_branches_executable':False,
                    'shared_world_benchmark':'RING-004 source-native authored synthetic task; strongest classical control ties full composition'}
        if name=='forest_catalog':return f.catalog(args.get('refresh',False),args.get('offset',0),args.get('limit',30))
        if name=='forest_inspect_source':return f.source(args['snapshot_id'],args['ref'],args['path'])
        if name=='forest_route':return forest_route(args['goals'],args.get('budget',6),args.get('max_methods',3))
        if name=='forest_start_trial':return f.start(args['goals'],args.get('budget',6),args.get('max_methods',3),
            args.get('kind','shared_world_004'),args.get('seed',2026110615),args.get('count',8))
        if name=='forest_resume_trial':return f.resume(args['forest_session_id'])
        if name=='forest_list_trials':return f.list_trials(args.get('limit',15))
        if name=='forest_feedback':return f.feedback(args['forest_session_id'],args['expected_revision'],args['decision'],args['review_note'])
        if name=='forest_execute_reviewed':return f.execute(args['forest_session_id'],args['expected_revision'])
    if name=='catalog_cartridges': return service.catalog()
    if name=='select_methods': return service.inspect(args['case'])
    if name=='start_session': return service.start(args['case'])
    if name=='resume_session': return service.resume(args['session_id'])
    if name=='list_sessions': return service.list_sessions(args.get('limit',20))
    if name=='record_feedback':
        return service.feedback(args['session_id'],args['expected_revision'],args['decision'],args['review_note'],
                                args.get('updated_case'),args.get('observed_outcome',''))
    if name=='execute_reviewed':return service.execute(args['session_id'],args['expected_revision'])
    if name=='reopen_session':return service.reopen(args['session_id'],args['expected_revision'],args['updated_case'],args['review_note'])
    if name=='reflect_session':
        result=service.resume(args['session_id'])
        return {'session_id':args['session_id'],'revision':result['revision'],
                'stage':result['stage'],'reflection':result.get('reflection',{'status':'AWAITING_APPROVAL_OR_EXECUTION'}),
                'next':result['next']}
    raise ServiceError('Unknown tool')


def rpc(service, message):
    """Return a JSON-RPC response, or None for a notification."""
    if not isinstance(message,dict) or message.get('jsonrpc') != '2.0':
        return {'jsonrpc':'2.0','id':None,'error':{'code':-32600,'message':'Invalid Request'}}
    if 'id' not in message:
        # Stateless initialized/progress/cancel notifications: acknowledged by HTTP 202.
        return None
    mid=message['id']
    if not isinstance(mid,(str,int)) or isinstance(mid,bool):
        return {'jsonrpc':'2.0','id':None,'error':{'code':-32600,'message':'Invalid ID'}}
    method=message.get('method')
    if method=='initialize':
        params=message.get('params',{})
        requested=params.get('protocolVersion') if isinstance(params,dict) else None
        chosen=requested if requested in ('2025-03-26','2025-06-18') else PROTOCOL
        data={'protocolVersion': chosen, 'capabilities': {'tools':{'listChanged':False}},
              'serverInfo':{'name':NAME,'version':VERSION},
              'instructions': ('Use MOTIF to solve a real task, not replace it. '
                'Start by selecting methods and inspecting their limits. '
                'Six built-in shared-case methods plus source-indexed MOTIF forest tools are available. '
                'At PLAN_REVIEW, explicitly return to the human before recording approval. '
                'At RESULT_REVIEW, show unresolved conflicts and next question before feedback. '
                'Do not call approve/accept unless user has actually authorized that review step; '
                'never infer real-world truth from simulated planning. '
                'Forest branches are NOT automatically admitted; source-native trials require pinned Git and Docker. '
                'RING-004 common-world performance ties a strong classical baseline. '
                'Preserve session ID and revision for resumption; no auto-continuation.')}
        return {'jsonrpc':'2.0','id':mid,'result':data}
    if method=='ping':return {'jsonrpc':'2.0','id':mid,'result':{}}
    if method=='tools/list':return {'jsonrpc':'2.0','id':mid,'result':{'tools':TOOLS}}
    if method=='tools/call':
        params=message.get('params')
        if not isinstance(params,dict) or not isinstance(params.get('name'),str):
            return {'jsonrpc':'2.0','id':mid,'error':{'code':-32602,'message':'Invalid tool arguments'}}
        try:
            result=dispatch(service,params['name'],params.get('arguments',{}))
            return {'jsonrpc':'2.0','id':mid,'result':{
                'content':[{'type':'text','text':json.dumps(result,sort_keys=True,ensure_ascii=True)}],
                'structuredContent': result,'isError':False}}
        except (ServiceError, ForestError, ValueError, TypeError, KeyError, IndexError) as exc:
            # Don't leak host paths or database details in errors.
            msg=str(exc)[:250]
            return {'jsonrpc':'2.0','id':mid,'result':{'content':[{'type':'text','text':msg}], 'isError':True}}
    return {'jsonrpc':'2.0','id':mid,'error':{'code':-32601,'message':'Method not found'}}


def create_app(service=None, api_key=None, allowed_origins=None):
    token = api_key if api_key is not None else os.environ.get('MOTIF_MCP_API_KEY','')
    if not isinstance(token,str) or len(token)<32 or '\n' in token:
        raise RuntimeError('MOTIF_MCP_API_KEY must be a 32+ character random bearer secret')
    service = service or MotifService(os.getenv('MOTIF_MCP_DB',str(DEFAULT_DB)))
    origin_set = set(allowed_origins if allowed_origins is not None else filter(None,os.getenv('MOTIF_ALLOWED_ORIGINS','').split(',')))
    app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)
    buckets=defaultdict(deque)

    @app.middleware('http')
    async def security(request: Request, call_next):
        origin=request.headers.get('origin')
        if origin and origin not in origin_set:
            return Response(status_code=403)
        if request.url.path=='/healthz':
            return await call_next(request)
        provided=request.headers.get('authorization','')
        good=provided.startswith('Bearer ') and hmac.compare_digest(provided[7:],token)
        if not good:
            return JSONResponse({'error':'unauthorized'},status_code=401,headers={'WWW-Authenticate':'Bearer'})
        # Conservative single process rate guard; a proxy should implement shared remote limits.
        now=time.monotonic()
        queue=buckets['single-owner']
        while queue and now-queue[0]>60:queue.popleft()
        if len(queue)>=120:
            return JSONResponse({'error':'rate_limited'},status_code=429)
        queue.append(now)
        reply=await call_next(request)
        reply.headers['Cache-Control']='no-store'
        reply.headers['X-Content-Type-Options']='nosniff'
        return reply

    @app.get('/healthz')
    def health():
        return {'service':NAME,'status':'running','version':VERSION,
                'mcp_endpoint':'/mcp','public_tools_auth_required':True}

    @app.get('/mcp')
    def no_sse():
        return Response(status_code=405,headers={'Allow':'POST'})

    @app.delete('/mcp')
    def no_remote_session():
        return Response(status_code=405,headers={'Allow':'POST'})

    @app.post('/mcp')
    async def mcp_post(request:Request):
        accept=request.headers.get('accept','')
        if 'application/json' not in accept or 'text/event-stream' not in accept:
            return JSONResponse({'error':'MCP requires Accept: application/json, text/event-stream'},status_code=406)
        media=request.headers.get('content-type','').split(';')[0].lower().strip()
        if media!='application/json':
            return JSONResponse({'error':'MCP JSON required'},status_code=415)
        if int(request.headers.get('content-length','0') or '0')>650000:
            return JSONResponse({'error':'Request exceeds bound'},status_code=413)
        payload=await request.body()
        if len(payload)>650000:
            return JSONResponse({'error':'Request exceeds bound'},status_code=413)
        try:
            message=json.loads(payload)
        except (ValueError,UnicodeError):
            return JSONResponse({'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Parse error'}},status_code=400)
        if isinstance(message,list):
            return JSONResponse({'jsonrpc':'2.0','id':None,'error':{'code':-32600,'message':'Batching is unsupported'}},status_code=400)
        response=rpc(service,message)
        if response is None:
            return Response(status_code=202)
        return JSONResponse(response)
    return app


def stdio_server(service=None):
    """Local Codex-compatible newline-delimited JSON-RPC option."""
    service=service or MotifService(os.getenv('MOTIF_MCP_DB',str(DEFAULT_DB)))
    for line in sys.stdin:
        try:
            message=json.loads(line)
            response=rpc(service,message)
        except Exception:
            response={'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Parse error'}}
        if response is not None:
            sys.stdout.write(json.dumps(response,separators=(',',':'))+'\n')
            sys.stdout.flush()


# Server initialization explicitly requires authentication secret; service stays local until run.
app = create_app() if os.environ.get('MOTIF_MCP_API_KEY') else None

if __name__=='__main__':
    if os.environ.get('MOTIF_MCP_STDIO')=='1':stdio_server()
    else:
        import uvicorn
        uvicorn.run(app,host=os.getenv('MOTIF_HOST','127.0.0.1'),port=int(os.getenv('PORT','8000')))
