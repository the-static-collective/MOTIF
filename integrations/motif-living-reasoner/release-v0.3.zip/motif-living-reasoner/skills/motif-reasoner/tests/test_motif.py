import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'motif.py'
spec = importlib.util.spec_from_file_location('motif_living', SCRIPT)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

BASE = {
    'question': 'What should we test next?', 'goals': {'review': 10},
    'claims': [{'id': 'a', 'topic': 'state', 'value': 'ready', 'source': 'report1', 'origin': 'one'},
               {'id': 'b', 'topic': 'state', 'value': 'unknown', 'source': 'report2', 'origin': 'one'}],
    'actions': [{'id': 'inspect', 'requires': [], 'enables': ['known'], 'cost': 1},
                {'id': 'test', 'requires': ['known'], 'enables': ['tested'], 'cost': 1},
                {'id': 'deploy', 'requires': ['permission'], 'enables': ['live'], 'cost': 1}],
    'available': [], 'budget': 12, 'action_budget': 2,
}

class MotifSkillTests(unittest.TestCase):
    def case(self, **kw):
        return m.parse_case({**BASE, **kw})

    def test_exact_selection_and_actual_shared_case_composition(self):
        c = self.case()
        r = m.route(c)
        self.assertEqual(len(r['selected']), 6)
        self.assertFalse(r['missing'])
        self.assertEqual(r['waves'][1], ['claim.challenge', 'work.plan'])
        out = m.run(c, r)
        self.assertEqual(out['outputs']['review']['conflicting_topics'], 1)
        self.assertEqual(out['outputs']['review']['blocked_actions'][0]['id'], 'deploy')
        self.assertIn('tested', out['outputs']['review']['new_declared_affordances'])
        self.assertFalse(out['external_actions_executed'])

    def test_unknown_goal_and_unbounded_input_hold(self):
        with self.assertRaises(m.HOLD):
            self.case(goals={'run-arbitrary-code': 100})
        with self.assertRaises(m.HOLD):
            self.case(budget=10**50)
        with self.assertRaises(m.HOLD):
            self.case(actions=[{'id': '../evil', 'requires': [], 'enables': [], 'cost': 1}])

    def test_unaffordable_goal_requires_revision(self):
        c = self.case(budget=0)
        r = m.route(c)
        self.assertIn('review', r['missing'])
        self.assertEqual(r['selected'], [])

    def test_no_external_action_from_untrusted_action(self):
        c = self.case(actions=[{'id': 'rm_everything', 'requires': [], 'enables': ['deleted'], 'cost': 1}])
        out = m.run(c, m.route(c))
        self.assertFalse(out['external_actions_executed'])
        self.assertNotIn('subprocess', m.__dict__)

    def test_reinspection_approval_run_feedback_return_reopen(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            inp, sess = folder / 'case.json', folder / 's.json'
            inp.write_text(json.dumps(BASE))
            self.assertEqual(m.main(['start', '--case', str(inp), '--session', str(sess)]), 0)
            self.assertEqual(m.read_session(sess)['stage'], 'PLAN_REVIEW')
            self.assertEqual(m.main(['run', '--session', str(sess)]), 2)
            self.assertEqual(m.main(['feedback', '--decision', 'approve', '--session', str(sess)]), 0)
            self.assertEqual(m.main(['run', '--session', str(sess)]), 0)
            self.assertEqual(m.read_session(sess)['stage'], 'RESULT_REVIEW')
            self.assertEqual(m.main(['feedback', '--decision', 'accept', '--observed-outcome',
                'Test outputs reviewed', '--session', str(sess)]), 0)
            self.assertEqual(m.read_session(sess)['stage'], 'RETURNED')
            c = {**BASE, 'goals': {'questions': 5}, 'question': 'What is still unknown?'}
            inp.write_text(json.dumps(c))
            self.assertEqual(m.main(['reopen', '--case', str(inp), '--session', str(sess)]), 0)
            s = m.read_session(sess)
            self.assertEqual(s['cycle'], 2)
            self.assertEqual(s['stage'], 'PLAN_REVIEW')
            self.assertEqual(s['routing']['selected'], ['source.audit','claim.challenge','question.forge'])

    def test_event_tampering_detected(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            inp, sess = folder / 'case.json', folder / 's.json'
            inp.write_text(json.dumps(BASE))
            self.assertEqual(m.main(['start', '--case', str(inp), '--session', str(sess)]), 0)
            s = json.loads(sess.read_text())
            s['events'][0]['details']['question'] = 'forged'
            sess.write_text(json.dumps(s))
            with self.assertRaises(m.HOLD):
                m.read_session(sess)

    def test_deterministic_receipts_and_no_fabricated_verification(self):
        c = self.case()
        self.assertEqual(m.digest(m.route(c)), m.digest(m.route(c)))
        out = m.run(c, m.route(c))
        self.assertFalse(out['outputs']['review']['real_world_answer_verified'])

if __name__ == '__main__':
    unittest.main()
