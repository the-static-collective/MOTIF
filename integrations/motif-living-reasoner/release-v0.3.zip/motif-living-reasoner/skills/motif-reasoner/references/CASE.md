# Common-case contract v0.1

The model or human supplies JSON with exactly:

- `question`: nonempty text, max 2,000 characters.
- `goals`: map from typed output artifact names (`sources`, `conflicts`, `questions`, `plan`, `frontier`, `review`) to integer priorities 1..100. The router covers the requested outputs under a finite cost limit.
- `budget`: integer 0..30, computation units for routing, **not** an API billing estimate.
- `claims`: list of up to 100 `{id, topic, value, source, origin}` objects. `origin` denotes the stated upstream source of the claim. These fields are descriptions and can be incorrect; the skill does not fetch or authenticate them.
- `available`: list of capability IDs actually available at the outset.
- `actions`: list of up to 60 hypothetical actions `{id, requires: [capability], enables: [capability], cost: integer}`; these are **planning propositions**, not executable side effects.
- `action_budget`: integer 0..1000, max total *declared* hypothetical action costs.

Allowed optional fields: `claims`, `actions`, `available`, `budget`, `action_budget`. Identifiers are lowercase ASCII letters plus digits, dots, hyphens or underscores (start with a letter). The scripts do not execute arbitrary supplied code or endpoints. All declared claims and action outcomes remain unverified unless separately checked.

## Walkthrough (from plugin root)

```bash
python skills/motif-reasoner/scripts/motif.py start \
  --case examples/first-spiral.json --session /tmp/motif-session.json
# PLAN_REVIEW: inspect route and ask a correction question.
python skills/motif-reasoner/scripts/motif.py feedback \
  --decision approve --note 'Selected methods reviewed' --session /tmp/motif-session.json
python skills/motif-reasoner/scripts/motif.py run --session /tmp/motif-session.json
# RESULT_REVIEW: show contradictory claims, unanswered questions and hypothetical affordances.
python skills/motif-reasoner/scripts/motif.py feedback \
  --decision accept --note 'Reviewed limitations' \
  --observed-outcome 'No external test yet' --session /tmp/motif-session.json
python skills/motif-reasoner/scripts/motif.py inspect --session /tmp/motif-session.json
# Edit the case file when new evidence changes the question; no silent feedback loop.
python skills/motif-reasoner/scripts/motif.py reopen \
  --case examples/first-spiral.json --session /tmp/motif-session.json
```

## Human collaboration checkpoints

`PLAN_REVIEW`: Did the system understand the actual question and choose valid methods? Return for correction; approval needed.

`RESULT_REVIEW`: Did the methods produce useful results on the actual supplied case? Explicitly capture ambiguity, wrong assumptions, contradictory evidence and next test. Accept, revise or hold.

`RETURNED`: The current cycle is complete. The agent should give the actual response and preserve the session. Reopening a prior session only happens on a later user request; no scheduled or autonomous follow-up.

`HELD`: Reject uncertain/unsafe/unaffordable routes and wait for explicit new input. Never covertly substitute a different method or perform an outside action.
