#!/usr/bin/env python3
"""MOTIF skill v0.1: bounded typed selection, real local composition and feedback loop.

No branch code, network, subprocess, credentials or real-world operations execute.
The six built-in operators process a common explicitly supplied case.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import sys
import tempfile

SCHEMA = "motif.living-reasoner.v1"
IDENT = re.compile(r"^[a-z][a-z0-9._-]{0,63}$")
# Shared typed artifacts, with explicit dependencies. This is an executable
# common-case integration, not proof that experimental branch code interoperates.
METHODS = (
    ("source.audit", ("input",), ("sources",), 1),
    ("claim.challenge", ("sources",), ("conflicts",), 2),
    ("question.forge", ("conflicts",), ("questions",), 1),
    ("work.plan", ("sources",), ("plan",), 2),
    ("affordance.frontier", ("plan",), ("frontier",), 2),
    ("integrate.review", ("questions", "frontier"), ("review",), 2),
)
GOALS = frozenset(x for _, _, outputs, _ in METHODS for x in outputs)
MAX_CASE_BYTES = 500_000
MAX_EVENTS = 40

class HOLD(ValueError):
    pass

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)

def digest(obj):
    return hashlib.sha256(canonical(obj).encode("utf-8")).hexdigest()

def ident(s):
    if type(s) is not str or not IDENT.fullmatch(s):
        raise HOLD("Invalid typed identifier")
    return s

def read_json(path):
    p = Path(path)
    if not p.is_file() or p.stat().st_size > MAX_CASE_BYTES:
        raise HOLD("Missing or oversized JSON input")
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError) as exc:
        raise HOLD("Invalid JSON input") from exc

def require_str(value, length=300):
    if type(value) is not str or not value.strip() or len(value) > length:
        raise HOLD("Missing or oversized text field")
    return value

def parse_case(raw):
    if type(raw) is not dict or set(raw) - {"question", "goals", "claims", "actions", "available", "budget", "action_budget"}:
        raise HOLD("Unknown case fields")
    require_str(raw.get("question"), 2000)
    goals = raw.get("goals")
    if type(goals) is not dict or not goals or len(goals) > len(GOALS):
        raise HOLD("Provide typed goals as {artifact: weight}")
    for key, weight in goals.items():
        if key not in GOALS or type(weight) is not int or not 1 <= weight <= 100:
            raise HOLD("Unknown or invalid typed goal")
    budget = raw.get("budget", 10)
    if type(budget) is not int or not 0 <= budget <= 30:
        raise HOLD("Invalid finite cartridge budget")
    action_budget = raw.get("action_budget", 40)
    if type(action_budget) is not int or not 0 <= action_budget <= 1000:
        raise HOLD("Invalid finite hypothetical action budget")
    claims = raw.get("claims", [])
    if type(claims) is not list or len(claims) > 100:
        raise HOLD("Invalid claim list")
    seen = set()
    for c in claims:
        if type(c) is not dict or set(c) != {"id", "topic", "value", "source", "origin"}:
            raise HOLD("Claims require id, topic, value, source, origin")
        ident(c["id"])
        for key in ("topic", "value", "source", "origin"):
            require_str(c[key], 300)
        if c["id"] in seen:
            raise HOLD("Duplicate claim id")
        seen.add(c["id"])
    actions = raw.get("actions", [])
    if type(actions) is not list or len(actions) > 60:
        raise HOLD("Invalid hypothetical action list")
    seen.clear()
    for a in actions:
        if type(a) is not dict or set(a) != {"id", "requires", "enables", "cost"}:
            raise HOLD("Actions require id, requires, enables, cost")
        ident(a["id"])
        if a["id"] in seen:
            raise HOLD("Duplicate action id")
        seen.add(a["id"])
        for key in ("requires", "enables"):
            vals = a[key]
            if type(vals) is not list or len(vals) > 20 or len(vals) != len(set(vals)):
                raise HOLD("Bad capability list")
            for v in vals:
                ident(v)
        if type(a["cost"]) is not int or not 1 <= a["cost"] <= 100:
            raise HOLD("Invalid action cost")
    available = raw.get("available", [])
    if type(available) is not list or len(available) > 40 or len(available) != len(set(available)):
        raise HOLD("Invalid available capabilities")
    for v in available:
        ident(v)
    # Round trip into a canonical JSON-only independent snapshot.
    return json.loads(canonical({"question": raw["question"], "goals": goals, "claims": claims,
        "actions": actions, "available": available, "budget": budget,
        "action_budget": action_budget}))

def route(case):
    """Exact subset search with typed dependency closure and deterministic waves."""
    candidates = []
    for mask in range(1 << len(METHODS)):
        chosen = [m for i, m in enumerate(METHODS) if mask & (1 << i)]
        cost = sum(m[3] for m in chosen)
        if cost > case["budget"]:
            continue
        produced = {"input"}
        waves = []
        remaining = list(chosen)
        while remaining:
            ready = [m for m in remaining if set(m[1]) <= produced]
            if not ready:
                break
            waves.append([m[0] for m in ready])
            produced.update(x for m in ready for x in m[2])
            remaining = [m for m in remaining if m not in ready]
        if remaining:
            continue
        covered = sorted(set(case["goals"]) & produced)
        missing = sorted(set(case["goals"]) - produced)
        weight = sum(case["goals"][x] for x in covered)
        # Full goal coverage dominates a cheap but incomplete partial result.
        key = (-weight, len(missing), cost, len(chosen), [m[0] for m in chosen])
        candidates.append((key, {"selected": [m[0] for m in chosen],
            "waves": waves, "cost": cost, "covered": covered, "missing": missing,
            "declared_goal_weight_covered": weight,
            "router": "EXACT_TYPED_SUBSET_SEARCH", "candidate_is_not_task_success": True}))
    if not candidates:
        raise HOLD("No valid method subset")
    candidates.sort(key=lambda pair: pair[0])
    result = candidates[0][1]
    singles = [entry[1] for entry in candidates if len(entry[1]["selected"]) <= 1]
    singles.sort(key=lambda e: (-e["declared_goal_weight_covered"], e["cost"], e["selected"]))
    baseline = singles[0]
    result["baseline_single_method"] = {
        "selected": baseline["selected"], "covered": baseline["covered"],
        "declared_goal_weight_covered": baseline["declared_goal_weight_covered"]}
    result["comparison_is_goal_coverage_not_task_accuracy"] = True
    return result

def op_source(case, artifacts):
    grouped = {}
    for c in case["claims"]:
        grouped.setdefault(c["origin"], []).append(c["id"])
    return {"sources": {"claims": case["claims"],
            "unique_upstream_origins": len(grouped),
            "shared_origin_groups": [sorted(ids) for ids in grouped.values() if len(ids) > 1],
            "note": "Source and origin are user-supplied labels, not authenticated provenance"}}

def op_challenge(case, artifacts):
    by_topic = {}
    for c in artifacts["sources"]["claims"]:
        by_topic.setdefault(c["topic"], {}).setdefault(c["value"], []).append(c["id"])
    conflicts = [{"topic": topic, "alternatives": values} for topic, values in sorted(by_topic.items()) if len(values) > 1]
    return {"conflicts": {"conflicting_topics": conflicts,
        "inference": "Different reported values are disagreements, not adjudicated facts",
        "shared_origin_groups": artifacts["sources"]["shared_origin_groups"]}}

def op_question(case, artifacts):
    questions = ["Which source-owned evidence would distinguish %s?" % x["topic"]
        for x in artifacts["conflicts"]["conflicting_topics"]]
    if not case["claims"]:
        questions.append("What independently checkable observations bear on this question?")
    if artifacts["conflicts"]["shared_origin_groups"]:
        questions.append("Are repeated reports independent, or derived from one origin?")
    if not questions:
        questions.append("What would falsify the leading interpretation?")
    return {"questions": {"next_questions": questions[:20],
        "unanswered_by_algorithm": True}}

def op_plan(case, artifacts):
    pending = list(case["actions"])
    available = set(case["available"])
    waves, expense = [], 0
    while pending:
        ready = [a for a in pending if set(a["requires"]) <= available]
        if not ready:
            break
        selected = []
        for a in ready:
            if expense + a["cost"] <= case["action_budget"]:
                selected.append(a)
                expense += a["cost"]
        if not selected:
            break
        waves.append([a["id"] for a in selected])
        available.update(v for a in selected for v in a["enables"])
        pending = [a for a in pending if a not in selected]
    return {"plan": {"hypothetical_waves": waves, "blocked": [
        {"id": a["id"], "missing_capabilities": sorted(set(a["requires"]) - available)} for a in pending],
        "declared_action_cost": expense, "available_after_hypothetical_actions": sorted(available),
        "performed_actions": [], "planner": "BOUNDED_GREEDY_DEPENDENCY_WAVES_NOT_OPTIMAL", "external_authority": "NONE"}}

def op_frontier(case, artifacts):
    avail = set(case["available"])
    reached = set(artifacts["plan"]["available_after_hypothetical_actions"])
    return {"frontier": {"new_hypothetical_affordances": sorted(reached - avail),
        "remaining_blockers": artifacts["plan"]["blocked"],
        "not_observed_or_authorized": True}}

def op_review(case, artifacts):
    return {"review": {"question": case["question"],
        "conflicting_topics": len(artifacts["conflicts"]["conflicting_topics"]),
        "competing_claims": artifacts["conflicts"]["conflicting_topics"],
        "reported_shared_origin_groups": artifacts["conflicts"]["shared_origin_groups"],
        "questions": artifacts["questions"]["next_questions"],
        "new_declared_affordances": artifacts["frontier"]["new_hypothetical_affordances"],
        "blocked_actions": artifacts["frontier"]["remaining_blockers"],
        "status": "HUMAN_REVIEW_REQUIRED", "real_world_answer_verified": False}}

HANDLERS = {"source.audit": op_source, "claim.challenge": op_challenge,
    "question.forge": op_question, "work.plan": op_plan,
    "affordance.frontier": op_frontier, "integrate.review": op_review}

def run(case, selection):
    artifacts = {"input": {"case_sha256": digest(case)}}
    events = []
    for wave in selection["waves"]:
        snapshot = dict(artifacts)
        outputs = {}
        for name in wave:
            delta = HANDLERS[name](case, snapshot)
            expected = set(next(m[2] for m in METHODS if m[0] == name))
            if set(delta) != expected or expected & outputs.keys():
                raise HOLD("Handler returned incompatible artifact contract")
            outputs.update(delta)
        artifacts.update(outputs)
        events.append({"methods": wave, "artifacts": sorted(outputs)})
    return {"outputs": {key: artifacts[key] for key in selection["covered"]},
        "execution_waves": events, "external_actions_executed": False,
        "source_branch_code_executed": False, "shared_case_processed": True}

def event(session, kind, details):
    log = session.setdefault("events", [])
    if len(log) >= MAX_EVENTS:
        raise HOLD("Review-event budget exhausted; export and open a new session")
    previous = log[-1]["hash"] if log else "0" * 64
    entry = {"sequence": len(log) + 1, "kind": kind, "details": details, "previous": previous}
    entry["hash"] = digest(entry)  # integrity fingerprint, NOT authentication
    log.append(entry)

def reinspection(case):
    selection = route(case)
    return {"case_sha256": digest(case), "question": case["question"],
        "case_claim_count": len(case["claims"]), "case_action_count": len(case["actions"]),
        "declared_goals": case["goals"], "routing": selection,
        "warning": "Input interpretation and capability declarations require human review"}

def atomic_write(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".motif-", suffix=".json", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(json.dumps(obj, indent=2, sort_keys=True) + "\n")
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)

def read_session(path):
    s = read_json(path)
    if type(s) is not dict or s.get("schema") != SCHEMA or s.get("stage") not in (
        "PLAN_REVIEW", "READY", "RESULT_REVIEW", "RETURNED", "HELD"):
        raise HOLD("Invalid session schema")
    if parse_case(s.get("case")) != s["case"] or digest(s["case"]) != s.get("case_sha256"):
        raise HOLD("Case changed without reinspection")
    expected = reinspection(s["case"])["routing"]
    if s.get("routing") != expected:
        raise HOLD("Route changed without reinspection")
    previous = "0" * 64
    for n, e in enumerate(s.get("events", []), 1):
        if type(e) is not dict or e.get("sequence") != n or e.get("previous") != previous:
            raise HOLD("Broken session event chain")
        content = {k: v for k, v in e.items() if k != "hash"}
        if digest(content) != e.get("hash"):
            raise HOLD("Altered session event")
        previous = e["hash"]
    return s

def print_session(s):
    return {"schema": SCHEMA, "stage": s["stage"], "cycle": s["cycle"],
        "inspection": reinspection(s["case"]),
        "result": s.get("result"), "last_event": s["events"][-1],
        "next": {"PLAN_REVIEW": "feedback --decision approve|revise|hold",
            "READY": "run", "RESULT_REVIEW": "feedback --decision accept|revise|hold",
            "RETURNED": "reopen --case updated.json", "HELD": "reopen --case updated.json"}[s["stage"]],
        "receipt_sha256": digest({"case": s["case_sha256"], "last_event": s["events"][-1]["hash"]})}

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command", choices=("start", "inspect", "feedback", "run", "reopen"))
    ap.add_argument("--case", type=Path)
    ap.add_argument("--session", type=Path, required=True)
    ap.add_argument("--decision", choices=("approve", "accept", "revise", "hold"))
    ap.add_argument("--note", default="")
    ap.add_argument("--observed-outcome", default="")
    args = ap.parse_args(argv)
    try:
        if len(args.note) > 2000 or len(args.observed_outcome) > 2000:
            raise HOLD("Oversized feedback")
        if args.command == "start":
            if not args.case or args.session.exists():
                raise HOLD("Provide --case and a new --session path")
            case = parse_case(read_json(args.case))
            inspection = reinspection(case)
            s = {"schema": SCHEMA, "stage": "PLAN_REVIEW", "cycle": 1,
                 "case": case, "case_sha256": digest(case), "routing": inspection["routing"], "events": []}
            event(s, "REINSPECT_AND_ROUTE", inspection)
        else:
            s = read_session(args.session)
            if args.command in ("reopen",) or (args.command == "feedback" and args.decision == "revise"):
                if args.command == "reopen" and s["stage"] not in ("RETURNED", "HELD"):
                    raise HOLD("Reopen only after return or hold")
                if args.command == "feedback" and s["stage"] not in ("PLAN_REVIEW", "RESULT_REVIEW"):
                    raise HOLD("Revise only at a review checkpoint")
                if not args.case:
                    raise HOLD("Explicit updated --case required for reinspection")
                case = parse_case(read_json(args.case))
                s["case"], s["case_sha256"] = case, digest(case)
                s["routing"] = route(case)
                s.pop("result", None)
                s["cycle"] += 1
                s["stage"] = "PLAN_REVIEW"
                event(s, "REINSPECT_AND_REPLAN", {"note": args.note, "inspection": reinspection(case)})
            elif args.command == "feedback":
                if not args.decision:
                    raise HOLD("Feedback requires --decision")
                if args.decision == "approve" and s["stage"] == "PLAN_REVIEW":
                    if s["routing"]["missing"]:
                        raise HOLD("Goals remain uncovered; revise the case or budget")
                    s["stage"] = "READY"
                    event(s, "HUMAN_APPROVED_ROUTING", {"note": args.note})
                elif args.decision == "accept" and s["stage"] == "RESULT_REVIEW":
                    s["stage"] = "RETURNED"
                    event(s, "HUMAN_RETURNED", {"note": args.note,
                        "observed_outcome": args.observed_outcome, "outcome_is_unverified_user_report": True})
                elif args.decision == "hold" and s["stage"] in ("PLAN_REVIEW", "RESULT_REVIEW"):
                    s["stage"] = "HELD"
                    event(s, "HUMAN_HELD", {"note": args.note})
                else:
                    raise HOLD("Decision not allowed at this checkpoint")
            elif args.command == "run":
                if s["stage"] != "READY":
                    raise HOLD("Human must approve routing before execution")
                s["result"] = run(s["case"], s["routing"])
                s["stage"] = "RESULT_REVIEW"
                event(s, "BOUNDED_SHARED_CASE_EXECUTION", {"result_sha256": digest(s["result"]),
                    "methods": s["routing"]["selected"]})
            elif args.command != "inspect":
                raise HOLD("Unknown command")
        if args.command != "inspect":
            atomic_write(args.session, s)
        print(json.dumps(print_session(s), indent=2, sort_keys=True))
        return 0
    except (HOLD, KeyError, TypeError, OSError) as exc:
        print(json.dumps({"schema": SCHEMA, "stage": "HOLD", "reason": str(exc),
            "external_actions_executed": False}), file=sys.stdout)
        return 2

if __name__ == "__main__":
    sys.exit(main())
