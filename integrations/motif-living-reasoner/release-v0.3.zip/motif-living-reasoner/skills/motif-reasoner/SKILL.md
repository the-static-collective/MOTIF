---
name: motif-reasoner
description: Solve consequential or uncertain questions through MOTIF's bounded executable cartridge selection, shared-case composition and explicit collaborative reinspection, feedback and return checkpoints. Use the MCP tools when connected; otherwise use the local script.
---

# MOTIF Living Reasoner v0.2 — collaborative execution

Answer the human's actual question. Do not substitute a process description for a useful answer or run an elaborate plan on trivial tasks.

## If the MOTIF MCP server is connected

1. Establish the user's real goal, verified evidence, competing interpretations, constraints and what a useful outcome would look like. Convert the specific request to the validated typed schema in `references/CASE.md`. Labels `source` and `origin` are **unverified** unless externally checked. Separate observation, hypothesis, recommendation and permission.
2. Optionally call `catalog_cartridges` and `select_methods`; describe coverage, cost, dependencies and unproven assumptions. Native research-branch methods are not available through this v0.2 service.
3. Call `start_session` once to preserve the draft. At `PLAN_REVIEW`, present the selected methods and seek *actual human feedback or approval*. Don't invent or auto-record assent. The user may approve multiple steps in one message if explicitly stated; do not manufacture review text.
4. On an actual approval, call `record_feedback(decision="approve", review_note=<faithful user approval>)` with the current `session_id` and `expected_revision`. Then `execute_reviewed`. It runs bounded built-in local computation only, not general code or external tools.
5. The resulting `RESULT_REVIEW` requires **reinspection and return**: report useful results, conflicts, one next question (`reflection.next_human_question`), and what evidence could change the recommendation. Then await the user's real `accept`, `revise` (with a changed case), or `hold`. Do not run another cycle automatically.
6. Across conversations use `list_sessions`, `resume_session`, and `reopen_session(updated_case=...)` with a reviewed corrected case. Preserve receipts and failed hypotheses; don't rewrite earlier events or imply hashes authenticate authors. Session revisions prevent stale writes.

Even when `reflect_session` finds a valuable question, it **cannot asynchronously contact the human**. Return the prompt in the current interaction. Never claim autonomous follow-up without a scheduled tool.

## If MCP is unavailable

The original `scripts/motif.py` CLI implements the same core bounded reasoning loop with explicit `PLAN_REVIEW` and `RESULT_REVIEW`; follow the local README. Do not claim the service was connected or a background MCP call occurred.

## Executable scope and research limits

The v0.2 server selects and executes six source-audit/challenge/question/planning/affordance/integration operators on one provided typed case. It does not browse, read live GitHub, invoke models, run arbitrary native branch code, commit source changes, send messages, or act in the external world. Its declared goals, cost and hypothetical future affordances are not measured task accuracy. Use external sources and strong conventional baselines to assess real improvement.

For every significant result, prefer a small usable answer and a preserved research receipt to unsupported claims about recursion, consciousness, or general intelligence.

## Forest extension — v0.3

For a question that can benefit from native MOTIF research, start with `forest_goals`, not a guessed branch. `forest_catalog` can inspect ALL current GitHub branches as non-executable source passports; `forest_inspect_source` reads by exact pinned commit. Select RING-003 typed goals and call `forest_route` for transparent method selection. Remember those affordance utilities are *declared hypotheses*.

For a source-native experiment, `forest_start_trial` creates a `PLAN_REVIEW` checkpoint. On explicit user approval only, call `forest_feedback(decision="approve")`, then `forest_execute_reviewed`; its Docker worker runs only three preapproved source-locked methods, or the RING-004 shared-evidence synthetic benchmark. At `RESULT_REVIEW`, present the classical control result, failure cases, and one next falsifying question. Then stop for the human's correction or return. Use `forest_resume_trial` / `forest_list_trials` across discussions. Never silently grant an indexed branch an executable adapter. If Docker or pinned git objects are unavailable, report the HOLD without pretending a native run occurred.

The developer's earlier approval to **build** the MCP connector is not automatic approval for every later trial. When the user says a particular trial is approved, preserve that approval faithfully at the corresponding checkpoint. The system does not independently attest human identity.
